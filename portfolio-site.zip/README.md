# Portfolio Site (HTML/CSS/JS)

A clean, responsive personal portfolio with dark/light mode, project cards, skills, about, and a contact form.

## Quick Start
1. Download and unzip the project.
2. Open `index.html` in your browser.
3. Edit text in `index.html`, update images in `/assets`, and tweak styles in `styles.css`.

## Customize
- Replace placeholders in the **Projects** section with your own links and images.
- Update the **About** text and avatar at `assets/avatar.png`.
- Add your resume as `assets/Moses_Colon_Resume.pdf` (or update the link).

## Deploy (GitHub Pages)
1. Create a new GitHub repository.
2. Upload all files (keep the same structure).
3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` (or `master`) and `/ (root)`. Save.
6. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.

## Notes
- The contact form is a demo. Connect a service like Formspree or Netlify Forms for real submissions.
- Theme preference persists in `localStorage`.
