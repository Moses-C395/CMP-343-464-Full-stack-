// Theme toggle with localStorage + prefers-color-scheme
(function(){
  const root = document.documentElement;
  const saved = localStorage.getItem('theme');
  if(saved){
    if(saved === 'light') root.classList.add('light');
  } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches){
    root.classList.add('light');
  }
  const btn = document.getElementById('theme-toggle');
  if(btn){
    btn.addEventListener('click', () => {
      root.classList.toggle('light');
      localStorage.setItem('theme', root.classList.contains('light') ? 'light':'dark');
      btn.textContent = root.classList.contains('light') ? '🌞' : '🌙';
    });
    btn.textContent = root.classList.contains('light') ? '🌞' : '🌙';
  }
})();

// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Basic contact form handling (client-side only demo)
const form = document.getElementById('contact-form');
const statusEl = document.getElementById('form-status');
if(form){
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const name = data.get('name')?.toString().trim();
    const email = data.get('email')?.toString().trim();
    const message = data.get('message')?.toString().trim();

    if(!name || !email || !message){
      statusEl.textContent = 'Please fill out all fields.';
      return;
    }

    // Demo success message (replace with real endpoint / service like Formspree)
    setTimeout(() => {
      statusEl.textContent = 'Thanks! Your message has been sent (demo).';
      form.reset();
    }, 400);
  });
}
